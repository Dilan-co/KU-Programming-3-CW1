import views.SystemUI;

public class Main {
    public static void main(String[] args) {
        // Initiate System
        SystemUI app = new SystemUI();
        app.runApp();
    }
}