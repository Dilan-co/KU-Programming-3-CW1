package models;

import java.util.HashMap;
import java.util.Map;

public class Treatment {
    // Prices for treatments
    private static final double ACNE_TREATMENT_PRICE = 2750.00;
    private static final double SKIN_WHITENING_PRICE = 7650.00;
    private static final double MOLE_REMOVAL_PRICE = 3850.00;
    private static final double LASER_TREATMENT_PRICE = 12500.00;

    // Map to hold treatment details with unique IDs as keys
    private static final Map<String, TreatmentDetail> treatmentPrices = new HashMap<>();

    // Static block to initialize the treatment prices map
    static {
        treatmentPrices.put("T001", new TreatmentDetail("T001", "Acne Treatment", ACNE_TREATMENT_PRICE));
        treatmentPrices.put("T002", new TreatmentDetail("T002", "Skin Whitening", SKIN_WHITENING_PRICE));
        treatmentPrices.put("T003", new TreatmentDetail("T003", "Mole Removal", MOLE_REMOVAL_PRICE));
        treatmentPrices.put("T004", new TreatmentDetail("T004", "Laser Treatment", LASER_TREATMENT_PRICE));
    }

    // Method to get the treatment prices map
    public static Map<String, TreatmentDetail> getTreatmentPrices() {
        return treatmentPrices;
    }
}