package models;

public class Patient extends Person {
    private String patientId;

    public Patient() {
    }

    public Patient(String patientId, String name, String email, String phoneNumber, String nic) {
        super(name, email, phoneNumber, nic);
        this.patientId = patientId;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }
}