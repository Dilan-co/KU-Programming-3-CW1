package models;

public class Invoice implements Payment {
    private static final int REGISTRATION_FEE = 500;
    private static final double TAX_RATE = 0.025;
    private double tax;
    private double totalAmount;
    private Appointment appointment;
    TreatmentDetail treatmentDetails;

    public Invoice() {
    }

    public Invoice(Appointment appointment, TreatmentDetail treatmentDetails) {
        this.appointment = appointment;
        this.treatmentDetails = treatmentDetails;
        calculateTotal();
    }

    private void calculateTotal() {
        double treatmentCost = this.treatmentDetails.getPrice();
        double totalCost = treatmentCost;
        this.tax = totalCost * TAX_RATE;
        // Total rounded to nearest decimal
        this.totalAmount = Math.ceil(totalCost + tax);
    }

    @Override
    public void processPayment(double amount) {
        // Processes after calculations completed (currently none since system doesn't
        // have payment methods)
        System.out.println("Payment  amount is LKR " + amount + " for the treatment.");
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void generateInvoice(Doctor docInfo) {
        System.out.println(" ");
        System.out.println("----------- INVOICE -----------");
        System.out.println(" ");
        System.out.println("Patient: " + appointment.getPatientName());
        System.out.println("Doctor: " + docInfo.getName());
        System.out.println("Treatment: " + this.treatmentDetails.getName());
        System.out.println("Treatment Cost: LKR " + this.treatmentDetails.getPrice());
        System.out.println("Tax: LKR " + this.tax);
        System.out.println("Total Amount: LKR " + this.totalAmount);
        System.out.println(" ");
    }
}