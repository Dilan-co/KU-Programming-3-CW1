package models;

public class TreatmentDetail {
    private String treatmentId;
    private String name;
    private double price;

    public TreatmentDetail() {
    }

    public TreatmentDetail(String treatmentId, String name, double price) {
        this.treatmentId = treatmentId;
        this.name = name;
        this.price = price;
    }

    public String getTreatmentId() {
        return treatmentId;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }
}