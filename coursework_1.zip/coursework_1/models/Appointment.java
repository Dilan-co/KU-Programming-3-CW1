package models;

import java.time.LocalDate;

public class Appointment {
    private String appointmentId;
    private String patientNIC;
    private String patientName;
    private String treatmentId;
    private String doctorId;
    private LocalDate date;
    private String time;
    private int isTreatmentCompleted;

    public Appointment() {
    }

    public Appointment(String appointmentId, String patientNIC, String patientName, String treatmentId, String doctorId,
            LocalDate date,
            String time, int isTreatmentCompleted) {
        this.appointmentId = appointmentId;
        this.patientNIC = patientNIC;
        this.patientName = patientName;
        this.treatmentId = treatmentId;
        this.doctorId = doctorId;
        this.date = date;
        this.time = time;
        this.isTreatmentCompleted = isTreatmentCompleted;
    }

    // Getters
    public String getAppointmentId() {
        return appointmentId;
    }

    public String getPatientNIC() {
        return patientNIC;
    }

    public String getPatientName() {
        return patientName;
    }

    public String getTreatmentId() {
        return treatmentId;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public int getIsTreatmentCompleted() {
        return isTreatmentCompleted;
    }

    // Setters
    public void setAppointmentId(String appointmentId) {
        this.appointmentId = appointmentId;
    }

    public void setPatientNIC(String patientNIC) {
        this.patientNIC = patientNIC;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public void setTreatmentId(String treatmentId) {
        this.treatmentId = treatmentId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setIsTreatmentCompleted(int isTreatmentCompleted) {
        this.isTreatmentCompleted = isTreatmentCompleted;
    }

    @Override
    public String toString() {
        return "Appointment{" +
                "appointmentId='" + appointmentId + '\'' +
                ", patientNIC='" + patientNIC + '\'' +
                ", patientName='" + patientName + '\'' +
                ", treatmentId='" + treatmentId + '\'' +
                ", doctorId='" + doctorId + '\'' +
                ", dateSelected=" + date +
                ", time='" + time + '\'' +
                '}';
    }
}