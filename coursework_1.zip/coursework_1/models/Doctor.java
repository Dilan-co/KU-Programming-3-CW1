package models;

public class Doctor extends Person {
    private String doctorId;

    public Doctor() {
    }

    public Doctor(String doctorId, String name, String email, String phoneNumber, String nic) {
        super(name, email, phoneNumber, nic);
        this.doctorId = doctorId;
    }

    public String getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }
}