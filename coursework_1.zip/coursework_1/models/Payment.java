package models;
public interface Payment {
    void processPayment(double amount);
}
