package controllers;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import models.Appointment;
import models.Doctor;
import models.Invoice;
import models.Patient;
import models.Treatment;
import models.TreatmentDetail;

public class AuroraSkinCareSystem {
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private List<String> appointmentDays = new ArrayList<>(Arrays.asList("MONDAY", "WEDNESDAY", "FRIDAY", "SATURDAY"));
    private List<Appointment> appointments = new ArrayList<>();
    private List<Doctor> doctors = new ArrayList<>();
    private List<Patient> patients = new ArrayList<>();
    private Map<String, Map<String, Map<String, String>>> doctorDayTimeAppointmentMap = new HashMap<>();

    // Method to generate date and time slots for appointments
    public void createDoctorDayTimeMap() {
        Map<String, Map<String, String>> dayTimeAppointmentMap = new HashMap<>();
        // Generating map for each day
        for (var day : appointmentDays) {
            Map<String, String> timeSlot = new LinkedHashMap<>();
            switch (day) {
                case "MONDAY" -> {
                    for (int h = 10; h < 13; h++) {
                        for (int m = 0; m < 60; m += 15) {
                            timeSlot.put(String.format("%02d:%02d", h, m), null);
                        }
                    }
                }
                case "WEDNESDAY" -> {
                    for (int h = 14; h < 17; h++) {
                        for (int m = 0; m < 60; m += 15) {
                            timeSlot.put(String.format("%02d:%02d", h, m), null);
                        }
                    }
                }
                case "FRIDAY" -> {
                    for (int h = 16; h < 20; h++) {
                        for (int m = 0; m < 60; m += 15) {
                            timeSlot.put(String.format("%02d:%02d", h, m), null);
                        }
                    }
                }
                case "SATURDAY" -> {
                    for (int h = 9; h < 13; h++) {
                        for (int m = 0; m < 60; m += 15) {
                            timeSlot.put(String.format("%02d:%02d", h, m), null);
                        }
                    }
                }
            }
            // System.err.println(timeSlot);
            dayTimeAppointmentMap.put(day, timeSlot);
        }
        // Generating map for each doctor
        for (var doctor : doctors) {
            this.doctorDayTimeAppointmentMap.put(doctor.getDoctorId(), dayTimeAppointmentMap);
        }
        // Printing the timeSlot list
        // System.out.println(this.doctorDayTimeAppointmentMap);
    }

    // Method to add a doctor to the system
    public String registerDoctor(String name, String email, String phoneNumber, String nic) {
        // Check for existing doctors with the NIC
        for (var doc : doctors) {
            if (doc.getNic().equalsIgnoreCase(nic)) {
                return doc.getDoctorId();
            }
        }
        // Generate a unique doctor ID
        String docId = "D00" + (doctors.size() + 1);
        Doctor newDoc = new Doctor(docId, name, email, phoneNumber, nic);
        doctors.add(newDoc);
        return docId;
    }

    // Method to find doctors available
    public List<Doctor> viewDoctors() {
        List<Doctor> foundDoctors = new ArrayList<>();
        for (var doctor : doctors) {
            foundDoctors.add(doctor);
        }
        return foundDoctors;
    }

    // Method to find doctor by ID
    public Doctor findDoctorByDoctorId(String doctorId) {
        for (var doctor : doctors) {
            if (doctor.getDoctorId().equalsIgnoreCase(doctorId)) {
                return doctor;
            }
        }
        return null;
    }

    // Method to find doctors by name
    // This findDoctorByName won't be necessary in the basic UI since doctor list
    // will be displayed
    public List<Doctor> findDoctorsByName(String name) {
        List<Doctor> foundDoctors = new ArrayList<>();
        for (var doctor : doctors) {
            if (doctor.getName().equalsIgnoreCase(name)) {
                foundDoctors.add(doctor);
            }
        }
        // Use this for the display doctor
        // for (var doc : foundDoctors) {
        // var aaa = doc.getDoctorId();
        // }
        return foundDoctors;
    }

    // Method to register a patient
    public String registerPatient(String nic, String name, String email, String phoneNumber) {
        // Check for existing patients with the NIC
        for (var patient : patients) {
            if (patient.getNic().equalsIgnoreCase(nic)) {
                return patient.getPatientId();
            }
        }
        // Generate a unique patient ID
        String patientId = "P00" + (patients.size() + 1);
        Patient newPatient = new Patient(patientId, name, email, phoneNumber, nic);
        patients.add(newPatient);
        return patientId;
    }

    // Method to search for an appointment by appointment ID
    public Appointment searchAppointmentByAppointmentId(String appointmentId) {
        for (var appointment : appointments) {
            if (appointment.getAppointmentId().equalsIgnoreCase(appointmentId)) {
                return appointment;
            }
        }
        return null;
    }

    // Method to search for an appointment by patient name
    public Appointment searchAppointmentByPatientName(String patientName) {
        for (var appointment : appointments) {
            if (appointment.getPatientName().equalsIgnoreCase(patientName)) {
                return appointment;
            }
        }
        System.out.println("Appointment not found");
        return null;
    }

    // Method to make an appointment
    // Give instructions to enter date & time in a specific format
    // (Ex -> 25/12/2024, 14:30)
    public String makeAppointment(String patientNIC, String patientName, String email, String phoneNumber,
            String treatmentId, String doctorId, String date, String time) {
        try {
            for (var patient : patients) {
                if (patient.getNic().equalsIgnoreCase(patientNIC)) {
                    // Updating patient information
                    patient.setPhoneNumber(phoneNumber);
                    patient.setEmail(email);
                    String appointmentId = createAppointment(patientNIC, patientName, treatmentId, doctorId, date,
                            time);
                    return appointmentId;
                }
            }
            // If system reach here, the patient wasn't found in the list
            System.out.println(" ");
            System.out.println("Patient not found. Registering new patient...");
            // Register new patient
            String newPatientId = registerPatient(patientNIC, patientName, email, phoneNumber);
            System.out.println("Patient registration successful. Created Patient ID: " + newPatientId);

            // Create the appointment for the new patient after registration
            String appointmentId = createAppointment(patientNIC, patientName, treatmentId, doctorId, date, time);
            return appointmentId;
        } catch (DateTimeParseException e) {
            return "dateError";
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
            return null;
        }
    }

    // Create new Appointment
    private String createAppointment(String patientNIC, String patientName, String treatmentId, String doctorId,
            String date, String time) {
        // Converting date to LocalDate format
        LocalDate dateSelected = LocalDate.parse(date, this.formatter);
        // Creating appointment ID
        String appointmentId = "A" + (appointments.size() + 1);
        Appointment appointment = new Appointment(appointmentId, patientNIC, patientName, treatmentId, doctorId,
                dateSelected, time, 0);
        appointments.add(appointment);
        // Reserving selected time for the appointment
        String timeBooked = reserveTimeForAppointment(appointmentId, doctorId, date, time);
        // Printing appointment list
        // System.out.println(appointments);
        return appointmentId;
    }

    // Method to update appointment doctor, date and time
    public String updateAppointmentPatientDetails(Appointment appointment, String email, String phoneNumber) {
        for (var patient : patients) {
            if (patient.getNic().equalsIgnoreCase(appointment.getPatientNIC())) {
                patient.setEmail(email);
                patient.setPhoneNumber(phoneNumber);
                return appointment.getAppointmentId();
            }
        }
        return null;
    }

    // Method to update appointment doctor, date and time
    public String updateAppointmentDoctorAndDateTime(Appointment appointment, String doctorId, String date,
            String time) {
        try {
            LocalDate oldDate = appointment.getDate();
            // Convert LocalDate to String
            String oldDateString = oldDate.format(formatter);
            // Remove previous appointment time
            String timeRemoved = reserveTimeForAppointment(null, appointment.getDoctorId(), oldDateString,
                    appointment.getTime());
            System.out.println("Removed appointment for " + oldDateString + " " + timeRemoved);
            // Reserving selected time for the appointment
            String timeBooked = reserveTimeForAppointment(appointment.getAppointmentId(), doctorId, date, time);
            System.out.println("Reserved new appointment for " + date + " " + timeBooked);
            // Converting date to LocalDate format
            LocalDate dateSelected = LocalDate.parse(date, this.formatter);
            appointment.setDoctorId(doctorId);
            appointment.setDate(dateSelected);
            appointment.setTime(time);
            return appointment.getAppointmentId();
        } catch (DateTimeParseException e) {
            return "dateError";
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
            return null;
        }
    }

    // Method to update appointment to complete treatment
    public String updateToCompleteTreatment(Appointment appointment, String treatmentId) {
        appointment.setTreatmentId(treatmentId);
        appointment.setIsTreatmentCompleted(1);
        return appointment.getAppointmentId();
    }

    // Filter appointments by date
    // Give instructions to enter date in a specific format (Ex -> 01/12/2024)
    public List<Appointment> viewAppointmentsByDate(String date) {
        List<Appointment> result = new ArrayList<>();
        LocalDate dateSelected = LocalDate.parse(date, this.formatter);
        for (Appointment appointment : appointments) {
            if (appointment.getDate().equals(dateSelected)) {
                result.add(appointment);
                return result;
            }
        }
        return null;
    }

    // Method to calculate total fee including treatment price and registration fee
    public double calculateTotalFeeAndGenerateInvoice(String appointmentId, String treatmentId, Doctor docInfo) {
        for (Appointment appointment : appointments) {
            if (appointment.getAppointmentId().equalsIgnoreCase(appointmentId)) {
                TreatmentDetail treatmentDetails = Treatment.getTreatmentPrices().get(treatmentId.toUpperCase());
                Invoice invoice = new Invoice(appointment, treatmentDetails);
                invoice.generateInvoice(docInfo);
                invoice.processPayment(invoice.getTotalAmount());
                // Updating the appointment
                updateToCompleteTreatment(appointment, treatmentId);
                return invoice.getTotalAmount();
            }
        }
        System.out.println("Appointment not found.");
        throw new IllegalArgumentException("Appointment not found");
    }

    // Method to display available treatments
    public void displayAvailableTreatments() {
        Map<String, TreatmentDetail> treatments = Treatment.getTreatmentPrices();
        for (TreatmentDetail detail : treatments.values()) {
            System.out.printf("Treatment ID: %s, Treatment: %s, Price: %.2f LKR%n",
                    detail.getTreatmentId(), detail.getName(), detail.getPrice());
        }
    }

    // Method to check day of the week
    // Give instructions to enter date in a specific format (Ex -> 01/12/2024)
    public String checkDayOfTheWeek(String date) {
        LocalDate dateSelected = LocalDate.parse(date, this.formatter);
        DayOfWeek dayOfWeek = dateSelected.getDayOfWeek();
        String dayOfWeekString = dayOfWeek.name(); // Convert to String type with UpperCase
        return dayOfWeekString;

        // Check if today is a specific day
        // if (dayOfWeek.equalsIgnoreCase(DayOfWeek.MONDAY)) {
        // System.out.println("It's Monday!");
        // }
    }

    // Method to add appointment for the selected time of related day
    // Give instructions to enter date in a specific format (Ex -> 01/12/2024)
    public String reserveTimeForAppointment(String appointmentId, String doctorId, String date, String time) {
        // Checking day
        String dayOfWeek = checkDayOfTheWeek(date);
        if (doctorId != null) {
            Map<String, Map<String, String>> dayTimeMap = doctorDayTimeAppointmentMap.get(doctorId);
            for (var dayMap : dayTimeMap.entrySet()) {
                String dayKey = dayMap.getKey();
                Map<String, String> timeSlots = dayMap.getValue();
                // Checking day of the week validation
                if (dayKey.equalsIgnoreCase(dayOfWeek)) {
                    for (var slot : timeSlots.entrySet()) {
                        String slotTime = slot.getKey();
                        // Checking time validation
                        if (slotTime.equalsIgnoreCase(time)) {
                            // Update the time slot with the appointment ID
                            timeSlots.put(slotTime, appointmentId);
                            // Update timeSlots back into the dayTimeMap
                            dayTimeMap.put(dayKey, timeSlots);
                            // Update doctorDayTimeAppointmentMap with the updated dayTimeMap
                            doctorDayTimeAppointmentMap.put(doctorId, dayTimeMap);
                            return slotTime;
                        }
                    }
                }
            }
            return null;
        }
        return null;
    }

    // Method to check available time slots for the related day
    // Give instructions to enter date in a specific format (Ex -> 01/12/2024)
    public String checkAvailableTimeForSelectedDoctor(String doctorId, String date) {
        // Checking day
        String dayOfWeek = checkDayOfTheWeek(date);
        Map<String, Map<String, String>> dayTimeMap = doctorDayTimeAppointmentMap.get(doctorId);
        for (var dayMap : dayTimeMap.entrySet()) {
            String dayKey = dayMap.getKey();
            Map<String, String> timeSlots = dayMap.getValue();
            // Checking day of the week validation
            if (dayKey.equalsIgnoreCase(dayOfWeek)) {
                for (var slot : timeSlots.entrySet()) {
                    String slotTime = slot.getKey();
                    String timeValue = slot.getValue();
                    // Checking time validation
                    if (timeValue == null) {
                        return slotTime;
                    }
                }
            }
        }
        return null;
    }

    // Method to print appointment reserve receipt
    public void printReceiptForAppointmentReservation(String appointmentId, String patientName, String doctorName,
            String selectedDate, String selectedTime) {
        System.out.println(" ");
        System.out.println("------------------------------------------------");
        System.out.println("RECEIPT FOR APPOINTMENT RESERVATION");
        System.out.println(" ");
        System.out.println("Appointment ID: " + appointmentId);
        System.out.println("Doctor Name : Dr." + doctorName);
        System.out.println("Patient Name: " + patientName);
        System.out.println("Appointment Date: " + selectedDate);
        System.out.println("Appointment Time: " + selectedTime);
        System.out.println(" ");
        System.out.println("Paid LKR 500");
        System.out.println(" ");
        System.out.println("Please be at the clinic 15min before the appointment time.");
        System.out.println(" ");
        System.out.println("------------------------------------------------");
        System.out.println(" ");
    };
}