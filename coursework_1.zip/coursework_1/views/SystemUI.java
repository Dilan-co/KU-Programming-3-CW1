package views;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import controllers.AuroraSkinCareSystem;
import models.Appointment;
import models.Doctor;

public class SystemUI {
    // Get current date and time
    private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public void runApp() {
        // Scanner
        Scanner scanner = new Scanner(System.in);
        // System instance
        AuroraSkinCareSystem system = new AuroraSkinCareSystem();
        // Register doctors to the system
        system.registerDoctor("Nishan Silva", "dr.silva@example.com", "0771234567", "602388821V");
        system.registerDoctor("Selwan Kumar", "dr.kumar@example.com", "0712345678", "648199203V");
        // Generating time slots for days
        system.createDoctorDayTimeMap();
        // Start CLI
        mainMenu(scanner, system);
    }

    private static void mainMenu(Scanner scanner, AuroraSkinCareSystem system) {

        System.out.println("---------------------------------------------------------------");
        System.out.println(" ");
        System.out.println("Aurora Healthcare Appointment Management Main Menu");
        System.out.println(" ");
        System.out.println("---------------------------------------------------------------");
        System.out.println(" ");
        System.out.println("1. Select Available Times and Book an Appointment");
        System.out.println("2. View Existing Appointments");
        System.out.println(" ");
        System.out.print("Enter the number to choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                viewAppointmentTimes(scanner, system, false, null);
                break;
            case 2:
                viewExistingAppointment(scanner, system);
                break;
            default:
                System.out.println("Invalid option, please try again.");
                // Go back to the main menu
                mainMenu(scanner, system);
                break;
        }
    }

    private static void viewAppointmentTimes(Scanner scanner, AuroraSkinCareSystem system, boolean isUpdate,
            Appointment appointment) {
        List<Doctor> docList = system.viewDoctors();
        System.out.println(" ");
        System.out.println("Doctors Available");
        System.out.println(" ");
        if (!docList.isEmpty()) {
            for (var doc : docList) {
                System.out.println("Doctor ID: " + doc.getDoctorId() + ", Doctor Name: Dr." + doc.getName());
            }
            System.out.println(" ");
            String docId = getValidId(scanner, system, "Doctor");
            String date = getValidDate(scanner);
            // Checking available time for selected doctor and date
            String resultTime = system.checkAvailableTimeForSelectedDoctor(docId, date);
            if (resultTime != null) {
                for (var doc : docList) {
                    String docIdFromData = doc.getDoctorId();
                    String docNameFromData = doc.getName();
                    if (docIdFromData.equalsIgnoreCase(docId)) {
                        System.out.println(" ");
                        System.out.println("Time available for Dr." + doc.getName() + " : " + resultTime);
                        System.out.println(" ");
                        System.out.println("1. Do you wish to book an appointment for the time available?");
                        System.out.println("2. Check time for another doctor.");
                        System.out.println(" ");
                        System.out.print("Enter the number to choose an option: ");
                        int choice = scanner.nextInt();
                        switch (choice) {
                            case 1:
                                addNewAppointment(scanner, system, isUpdate, appointment, docIdFromData,
                                        docNameFromData, date, resultTime);
                                break;
                            case 2:
                                viewAppointmentTimes(scanner, system, isUpdate, appointment);
                                break;
                            default:
                                System.out.println("Invalid option, please try again.");
                                viewAppointmentTimes(scanner, system, isUpdate, appointment);
                                break;
                        }
                    } else {
                        System.out.println("Unfortunate Error. Try again...");
                        viewAppointmentTimes(scanner, system, isUpdate, appointment);
                    }
                }
            } else {
                System.out.println("No Booking Time Available In " + date + ". Try again...");
                viewAppointmentTimes(scanner, system, isUpdate, appointment);
            }

        } else {
            System.out.println("No doctors available. Returning to Main Menu...");
            mainMenu(scanner, system);
        }

        // Other operations for Option 2
    }

    private static void addNewAppointment(Scanner scanner, AuroraSkinCareSystem system, boolean isUpdate,
            Appointment appointment, String selectedDocId, String selectedDocName, String selectedDate,
            String selectedTime) {
        System.out.println(" ");
        System.out.println("You are booking an appointment for Dr." + selectedDocName + " on " + selectedDate + " at "
                + selectedTime);
        if (!isUpdate) {
            System.out.println(" ");
            System.out.println("Patient will need to pay LKR 500 to reserve the appointment time.");
        }
        System.out.println(" ");
        System.out.println("1. Proceed to book an appointment");
        System.out.println("2. Go to Main Menu");
        System.out.println(" ");
        System.out.print("Enter the number to choose an option: ");
        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                if (isUpdate && appointment != null) {
                    String result = system.updateAppointmentDoctorAndDateTime(appointment, selectedDocId, selectedDate,
                            selectedTime);
                    if (result == null) {
                        System.out.println(" ");
                        System.out.println("Unfortunate, Error occurred while booking the appointment.");
                        System.out.println("Returning to available time check step.");
                        viewAppointmentTimes(scanner, system, isUpdate, appointment);
                    } else if (result.equalsIgnoreCase("dateError")) {
                        System.out.println(" ");
                        System.out.println("Invalid date format.");
                        System.out.println("Returning to available time check step.");
                        viewAppointmentTimes(scanner, system, isUpdate, appointment);
                    } else {
                        System.out.println("Appointment Reserve Successful. Appointment ID: " + result);
                        System.out.println(" ");
                        // Returning to Main Menu after booking completed
                        System.out.println("Press Enter to return to Main Menu:");
                        scanner.nextLine();
                        System.out.println("Returning to Main Menu...");
                        mainMenu(scanner, system);
                    }
                } else {
                    System.out.println(" ");
                    System.out.print("Enter the patient Name: ");
                    String patientName = scanner.next();
                    System.out.print("Enter the patient NIC: ");
                    String patientNic = scanner.next();
                    // Pattern checking Email
                    String patientEmail = getValidEmail(scanner);
                    // Pattern checking Phone Number
                    String patientTelephoneNumber = getValidPhoneNumber(scanner);
                    String result = system.makeAppointment(patientNic, patientName, patientEmail,
                            patientTelephoneNumber, null, selectedDocId, selectedDate, selectedTime);
                    if (result == null) {
                        System.out.println(" ");
                        System.out.println("Unfortunate, Error occurred while booking the appointment.");
                        System.out.println("Returning to available time check step.");
                        viewAppointmentTimes(scanner, system, isUpdate, appointment);
                    } else if (result.equalsIgnoreCase("dateError")) {
                        System.out.println(" ");
                        System.out.println("Invalid date format.");
                        System.out.println("Returning to available time check step.");
                        viewAppointmentTimes(scanner, system, isUpdate, appointment);
                    } else {
                        System.out.println(" ");
                        System.out.println("Appointment Reserve Successful. Appointment ID: " + result);
                        System.out.println("Collect the payment of LKR 500.");
                        System.out.println(" ");
                        System.out.println("Press Enter to print the receipt: ");
                        scanner.nextLine();
                        // Print the receipt
                        system.printReceiptForAppointmentReservation(result, patientName, selectedDocName, selectedDate,
                                selectedTime);
                        // Returning to Main Menu after booking completed
                        System.out.println("Press Enter to return to Main Menu:");
                        scanner.nextLine();
                        System.out.println("Returning to Main Menu...");
                        mainMenu(scanner, system);
                    }
                }
                break;
            case 2:
                mainMenu(scanner, system);
                break;
            default:
                System.out.println("Invalid option, please try again.");
                addNewAppointment(scanner, system, isUpdate, appointment, selectedDocId, selectedDocName, selectedDate,
                        selectedTime);
                break;
        }
    }

    private static void viewExistingAppointment(Scanner scanner, AuroraSkinCareSystem system) {
        // add view appointment by ID , view appointment by patient name , view
        // appointment details filtered by date
        List<Doctor> docList = system.viewDoctors();
        System.out.println(" ");
        System.out.println("1. View Appointments by Date");
        System.out.println("2. View Appointment by Appointment ID");
        System.out.println("3. View Appointment by Patient Name");
        System.out.println("4. Go to Main Menu");
        System.out.println(" ");
        System.out.print("Enter the number to choose an option: ");
        int choice = scanner.nextInt();
        System.out.println(" ");
        switch (choice) {
            // View Appointments By Date
            case 1:
                String selectedDate = getValidDate(scanner);
                List<Appointment> resultListByDate = system.viewAppointmentsByDate(selectedDate);
                System.out.println(" ");
                System.out.println("APPOINTMENT LIST BY DATE " + selectedDate);
                System.out.println(" ");
                System.out.println("---------------------------------------------------------------");
                System.out.println(" ");
                if (resultListByDate != null) {
                    for (var appointment : resultListByDate) {
                        boolean doctorFound = false;
                        if (!docList.isEmpty()) {
                            for (var doc : docList) {
                                if (doc.getDoctorId().equalsIgnoreCase(appointment.getDoctorId())) {
                                    // Convert LocalDate to String using the formatter
                                    LocalDate appointmentDate = appointment.getDate();
                                    String formattedDate = appointmentDate.format(formatter);
                                    System.out.println(
                                            "Appointment ID: " + appointment.getAppointmentId() +
                                                    "\nPatient Name: " + appointment.getPatientName() +
                                                    "\nIs Treatment Completed: "
                                                    + (appointment.getIsTreatmentCompleted() == 1 ? "YES" : "NO")
                                                    + "\nDoctor ID: " + appointment.getDoctorId() +
                                                    "\nDoctor Name: " + doc.getName() +
                                                    "\nAppointment Date: " + formattedDate +
                                                    "\nAppointment Time: " + appointment.getTime());
                                    System.out.println(" ");
                                    System.out
                                            .println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
                                    System.out.println(" ");
                                    doctorFound = true;
                                    break;
                                }
                            }
                            // If no doctor was found for the current appointment
                            if (!doctorFound) {
                                System.out.println(
                                        "Doctor not found for Appointment ID: " + appointment.getAppointmentId() + "");
                            }
                        } else {
                            System.out.println("No Doctors Available. Returning to Main Menu...");
                            mainMenu(scanner, system);
                        }
                    }
                    System.out.println(" ");
                    System.out.println("1. Update an Appointment");
                    System.out.println("2. Go to Main Menu");
                    System.out.println(" ");
                    System.out.print("Enter the number to choose an option: ");
                    int selection = scanner.nextInt();
                    System.out.println(" ");
                    switch (selection) {
                        case 1:
                            String appointmentIdToEdit = getValidId(scanner, system, "Appointment");
                            if (!resultListByDate.isEmpty()) {
                                for (var appointment : resultListByDate) {
                                    if (appointment.getAppointmentId().equalsIgnoreCase(appointmentIdToEdit)) {
                                        updateAppointment(scanner, system, appointment, docList);
                                    }
                                }
                                System.out.println("Invalid Appointment ID, please try again.");
                                viewExistingAppointment(scanner, system);
                            }
                            break;
                        case 2:
                            System.out.println("Returning to Main Menu...");
                            mainMenu(scanner, system);
                            break;
                        default:
                            System.out.println("Invalid option, please try again.");
                            viewExistingAppointment(scanner, system);
                            break;
                    }
                } else {
                    System.out.println("No Appointments on " + selectedDate + " , please try again.");
                    viewExistingAppointment(scanner, system);
                }
                break;
            // View Appointment By Appointment ID
            case 2:
                System.out.println(" ");
                String appointmentId = getValidId(scanner, system, "Appointment");
                Appointment appointmentByID = system.searchAppointmentByAppointmentId(appointmentId);
                if (appointmentByID != null) {
                    if (!docList.isEmpty()) {
                        for (var doc : docList) {
                            if (doc.getDoctorId().equalsIgnoreCase(appointmentByID.getDoctorId())) {
                                // Convert LocalDate to String using the formatter
                                LocalDate appointmentDate = appointmentByID.getDate();
                                String formattedDate = appointmentDate.format(formatter);
                                System.out.println(" ");
                                System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
                                System.out.println(" ");
                                System.out.println(
                                        "Appointment ID: " + appointmentByID.getAppointmentId() +
                                                "\nPatient Name: " + appointmentByID.getPatientName() +
                                                "\nIs Treatment Completed: "
                                                + (appointmentByID.getIsTreatmentCompleted() == 1 ? "YES" : "NO")
                                                + "\nDoctor ID: " + appointmentByID.getDoctorId() +
                                                "\nDoctor Name: " + doc.getName() +
                                                "\nAppointment Date: " + formattedDate +
                                                "\nAppointment Time: " + appointmentByID.getTime());
                                System.out.println(" ");
                                System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
                                System.out.println(" ");
                                System.out.println("1. Update the Appointment");
                                System.out.println("2. Go to Main Menu");
                                System.out.println(" ");
                                System.out.print("Enter the number to choose an option: ");
                                int selection = scanner.nextInt();
                                System.out.println(" ");
                                switch (selection) {
                                    case 1:
                                        updateAppointment(scanner, system, appointmentByID, docList);
                                        break;
                                    case 2:
                                        System.out.println("Returning to Main Menu...");
                                        mainMenu(scanner, system);
                                        break;
                                    default:
                                        System.out.println("Invalid option, please try again.");
                                        viewExistingAppointment(scanner, system);
                                        break;
                                }
                            }
                        }
                        System.out.println("Doctor not found, please try again.");
                        viewExistingAppointment(scanner, system);
                    } else {
                        System.out.println("No Doctors Available. Returning to Main Menu...");
                        mainMenu(scanner, system);
                    }
                } else {
                    System.out.println("No Appointments on appointment ID: " + appointmentId + " , please try again.");
                    viewExistingAppointment(scanner, system);
                }
                break;
            // View Appointment By Patient Name
            case 3:
                System.out.println(" ");
                System.out.print("Enter the patient Name: ");
                String selectedName = scanner.next();
                Appointment appointmentByName = system.searchAppointmentByPatientName(selectedName);
                if (appointmentByName != null) {
                    if (!docList.isEmpty()) {
                        for (var doc : docList) {
                            if (doc.getDoctorId().equalsIgnoreCase(appointmentByName.getDoctorId())) {
                                // Convert LocalDate to String using the formatter
                                LocalDate appointmentDate = appointmentByName.getDate();
                                String formattedDate = appointmentDate.format(formatter);
                                System.out.println(" ");
                                System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
                                System.out.println(" ");
                                System.out.println(
                                        "Appointment ID: " + appointmentByName.getAppointmentId() +
                                                "\nPatient Name: " + appointmentByName.getPatientName() +
                                                "\nIs Treatment Completed: "
                                                + (appointmentByName.getIsTreatmentCompleted() == 1 ? "YES" : "NO")
                                                + "\nDoctor ID: " + appointmentByName.getDoctorId() +
                                                "\nDoctor Name: " + doc.getName() +
                                                "\nAppointment Date: " + formattedDate +
                                                "\nAppointment Time: " + appointmentByName.getTime());
                                System.out.println(" ");
                                System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
                                System.out.println(" ");
                                System.out.println("1. Update the Appointment");
                                System.out.println("2. Go to Main Menu");
                                System.out.println(" ");
                                System.out.print("Enter the number to choose an option: ");
                                int selection = scanner.nextInt();
                                System.out.println(" ");
                                switch (selection) {
                                    case 1:
                                        updateAppointment(scanner, system, appointmentByName, docList);
                                        break;
                                    case 2:
                                        System.out.println("Returning to Main Menu...");
                                        mainMenu(scanner, system);
                                        break;
                                    default:
                                        System.out.println("Invalid option, please try again.");
                                        viewExistingAppointment(scanner, system);
                                        break;
                                }
                            }
                        }
                        System.out.println("Doctor not found, please try again.");
                        viewExistingAppointment(scanner, system);
                    } else {
                        System.out.println("No Doctors Available. Returning to Main Menu...");
                        mainMenu(scanner, system);
                    }
                } else {
                    System.out.println("No Appointments on the Name: " + selectedName + " , please try again.");
                    viewExistingAppointment(scanner, system);
                }
                break;

            default:
                System.out.println("Invalid option, please try again.");
                viewExistingAppointment(scanner, system);
                break;
        }

    }

    private static void updateAppointment(Scanner scanner, AuroraSkinCareSystem system, Appointment appointment,
            List<Doctor> docList) {
        System.out.println(" ");
        System.out.println("You are updating Appointment ID:" + appointment.getAppointmentId());
        System.out.println(" ");
        System.out.println("1. Update Patient Details");
        System.out.println("2. Change Doctor or Appointment Date");
        // Making "Complete Treatment" option unavailable if it's already completed
        if (appointment.getIsTreatmentCompleted() == 0) {
            System.out.println("3. Complete Treatment and Pay");
            System.out.println("4. Go to Main Menu");
        } else {
            System.out.println("3. Go to Main Menu");
        }
        System.out.println(" ");
        System.out.print("Enter the number to choose an option: ");
        int choice = scanner.nextInt();
        switch (choice) {
            // Update Patient Details
            case 1:
                System.out.println(" ");
                System.out.println("Only patient Email and Telephone Number can be updated.");
                System.out.println(" ");
                // Pattern checking Email
                String patientEmail = getValidEmail(scanner);
                // Pattern checking Phone Number
                String patientTelephoneNumber = getValidPhoneNumber(scanner);
                String result = system.updateAppointmentPatientDetails(appointment, patientEmail,
                        patientTelephoneNumber);
                if (result == null) {
                    System.out.println(" ");
                    System.out.println("Unfortunate, Error occurred while updating the appointment.");
                    System.out.println("Returning to update appointment step.");
                    updateAppointment(scanner, system, appointment, docList);
                } else {
                    System.out.println(" ");
                    System.out.println("Appointment Update Successful. Appointment ID: " + result);
                    System.out.println(" ");
                    // Returning to Main Menu after updating completed
                    System.out.println("Press Enter to return to Main Menu:");
                    scanner.nextLine();
                    System.out.println("Returning to Main Menu...");
                    mainMenu(scanner, system);
                }
                break;
            // Change Doctor and Time
            case 2:
                viewAppointmentTimes(scanner, system, true, appointment);
                break;
            // Complete the Treatment
            case 3:
                if (appointment.getIsTreatmentCompleted() == 0) {
                    // Completing Treatment
                    completeTreatmentAndPay(scanner, system, appointment, docList);
                } else {
                    mainMenu(scanner, system);
                }
                break;
            case 4:
                if (appointment.getIsTreatmentCompleted() == 0) {
                    mainMenu(scanner, system);
                } else {
                    System.out.println("Invalid option, please try again.");
                    updateAppointment(scanner, system, appointment, docList);
                }
                break;
            default:
                System.out.println("Invalid option, please try again.");
                updateAppointment(scanner, system, appointment, docList);
                break;
        }
    }

    private static void completeTreatmentAndPay(Scanner scanner, AuroraSkinCareSystem system, Appointment appointment,
            List<Doctor> docList) {
        System.out.println("Treatments Available");
        System.out.println("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
        System.out.println(" ");
        system.displayAvailableTreatments();
        System.out.println(" ");
        System.out.print("Enter the Treatment ID: ");
        String treatmentId = getValidId(scanner, system, "Treatment");
        for (var doc : docList) {
            if (doc.getDoctorId().equalsIgnoreCase(appointment.getDoctorId())) {
                double total = system.calculateTotalFeeAndGenerateInvoice(appointment.getAppointmentId(),
                        treatmentId, doc);
                System.out.println("Press Enter to return to Main Menu:");
                scanner.nextLine();
                System.out.println("Returning to Main Menu...");
                mainMenu(scanner, system);
            }
        }
    }

    // ====================================================================================
    // PATTERN CHECKING SECTION

    // Recursive method to prompt user until a valid docId/appointmentId is entered
    public static String getValidId(Scanner scanner, AuroraSkinCareSystem system, String idType) {
        // Regular expression pattern for validating ID
        String pattern = "";
        if (idType.equalsIgnoreCase("Doctor")) {
            pattern = "(?i)D00\\d{1}";
        } else if (idType.equalsIgnoreCase("Appointment")) {
            pattern = "(?i)A\\d{1,2}";
        } else if (idType.equalsIgnoreCase("Treatment")) {
            pattern = "(?i)T00\\d{1}";
        }
        // Checking if pattern is empty, indicating an invalid idType
        if (pattern.isEmpty()) {
            System.out.println("Invalid ID type provided.");
            System.out.println("Returning to Main Menu...");
            mainMenu(scanner, system);
        }

        // Prompt user for the ID
        System.out.print("Enter the " + idType + " ID: ");
        String id = scanner.next();

        if (isValidId(id, pattern)) {
            return id.toUpperCase();
        } else {
            System.out.println(" ");
            System.out.println("Invalid " + idType + " ID format. Please try again.");
            System.out.println(" ");
            // Recursively call the method again if the format is incorrect
            return getValidId(scanner, system, idType);
        }
    }

    // Pattern check for errors
    public static boolean isValidId(String id, String pattern) {
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(id);
        // Check if format matches and return validity
        return m.matches();
    }

    // Recursive method to prompt user until a valid date is entered
    public static String getValidDate(Scanner scanner) {
        System.out.println(" ");
        System.out.println("DATE FORMAT should be --> 09/02/2024 | day/month/year ");
        System.out.print("Enter the date to view available time: ");
        String date = scanner.next();

        // Validate the date format
        if (isValidDate(date)) {
            return date;
        } else {
            System.out.println(" ");
            System.out.println("Invalid date format. Please try again.");
            System.out.println(" ");
            // Recursively call the method again if the format is incorrect
            return getValidDate(scanner);
        }
    }

    // Method to validate the date using DateTimeFormatter
    public static boolean isValidDate(String date) {
        try {
            LocalDate.parse(date, formatter);
            // If parsing is successful, it's a valid date
            return true;
        } catch (DateTimeParseException e) {
            // If parsing fails, it's an invalid date
            return false;
        }
    }

    // Recursive method to prompt user until a valid email is entered
    public static String getValidEmail(Scanner scanner) {
        // Regex pattern for validating email
        String emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,}(?:\\.[a-zA-Z]{2,})*$";

        // Prompt user for email
        System.out.print("Enter the patient Email: ");
        String email = scanner.next();

        // Check if the email matches the pattern
        if (isValidEmail(email, emailPattern)) {
            return email; // Return valid email
        } else {
            System.out.println(" ");
            System.out.println("Invalid email format. Please try again.");
            System.out.println(" ");
            return getValidEmail(scanner);
        }
    }

    // Method to check if the email matches the pattern
    public static boolean isValidEmail(String email, String pattern) {
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(email);
        return m.matches();
    }

    // Recursive method to prompt user until a valid phone number is entered
    public static String getValidPhoneNumber(Scanner scanner) {
        // Regex pattern for validating 10-digit phone number
        String phonePattern = "^\\d{10}$";

        // Prompt user for phone number
        System.out.println("Telephone Number should contain 10 digits.");
        System.out.print("Enter the patient Telephone Number: ");
        String phoneNumber = scanner.next();

        // Check if the phone number matches the pattern
        if (isValidPhoneNumber(phoneNumber, phonePattern)) {
            return phoneNumber; // Return valid phone number
        } else {
            System.out.println(" ");
            System.out.println("Invalid phone number format. Please try again.");
            System.out.println(" ");
            return getValidPhoneNumber(scanner);
        }
    }

    // Method to check if the phone number matches the pattern
    public static boolean isValidPhoneNumber(String phoneNumber, String pattern) {
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(phoneNumber);
        return m.matches();
    }
}
